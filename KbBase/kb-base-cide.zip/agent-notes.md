<!-- section:l0.anchor -->
Minimal public header for KB-Base CIDE smoke.
<!-- /section:l0.anchor -->

Тело до маркера `public-cut` попадает в bundle CIDE.

