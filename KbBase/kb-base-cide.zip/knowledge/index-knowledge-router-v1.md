# Knowledge Router Index v1

## Purpose

Single entrypoint for fast navigation across the knowledge base under tight context limits.

**Структурный вход в дерево (корзины, таксономия):** `00-entry-kb-v1.md` → `META/kb-taxonomy-v1.md` — до маршрутизации по доменам ниже.

Документ разделён на три слоя: **А — маршрутизация** (какой домен, какой порядок чтения), **Б — операционный базис** (L0 и правила агента до или параллельно домену; **полный текст:** `router-operational-baseline-v1.md`), **В — безопасность и сопровождение индекса** (Safety Checks — **`index-knowledge-router-safety-v1.md`**; правки структуры роутера, списки `section_id`, **How to add a domain** — **`index-knowledge-router-maintenance-v1.md`**). Детальные **триггеры по формулировкам запроса** — в `index-knowledge-router-supplement-v1.md` (секции `router-*`).

## А. Маршрутизация (домены, порядок, бюджет)

### Fast Start (60-Second Rehydrate)

1. Read `status-*` for the active domain.
2. Read matching `playbook-*` for operating contracts.
3. Read one `matrix-*` only if transfer/routing is needed.
4. Read `kb-*` only for detailed evidence/rule extraction.
5. Update outcome in canonical index and domain status if scope changed.

### L1 pool (agent-notes, load on demand)

- Тяжёлые секции заметок (HPMOR-батчи, it-source-mini-index, knowledge-index, world-human-system, psychology-gender-studies — полный текст в `worlds/psychology-models/psychology-gender-studies-subdomain-v1.md`, imc-ui-ux-vision) вынесены в L1: не входят в default hot context.
- По запросу: `route_context(query)` или чтение `knowledge/agent-notes-l1-pool.md` (если создан) / поиск по section ID в agent-notes.

### Retrieval Order Contract

- **Order:** `status -> playbook -> matrix -> kb`.
- **Rule:** never start from large `kb-*` files unless a concrete question requires it.
- **Rule:** if two files disagree, prefer `status-*` and domain `playbook-*` as the source of current operating contract.

### Work / Sysadmin domains (Zabbix, Grafana, сети, 1С, nginx и др.)

- **Роутер:** `knowledge/domain-index-v1.md` — тип задачи → домен → playbook и kb в **корне `knowledge/`**. Загружать по ключевым словам (Zabbix, Grafana, дашборд, OSI, топология, прокси, мониторинг, 413, nginx, 1С, SSH, …) сначала domain-index, затем указанные там playbook-* и при необходимости kb-*-reference-v1.md.

### Domain Entry Map

<!-- section:domain-entry-map-table -->
| Domain | Entry status | Primary playbook | Router/matrix |
| --- | --- | --- | --- |
| Git | `worlds/collaboration-git-pr/status-git-v1.md` | `worlds/collaboration-git-pr/playbook-git-workflow-v1.md` | `worlds/collaboration-git-pr/kb-git-safety-and-recovery-rules-v1.md`; runbook multi-remote — `worlds/collaboration-git-pr/runbook-git-multi-remote-backup-v1.md`; hub — `worlds/collaboration-git-pr/README.md` |
| PR Review | `worlds/collaboration-git-pr/status-pr-review-v1.md` | `worlds/collaboration-git-pr/playbook-pr-review-v1.md` | `worlds/collaboration-git-pr/kb-pr-review-risk-rules-v1.md`; hub — `worlds/collaboration-git-pr/README.md` |
| HCI | `worlds/hci-ux-dx/status-hci-v1.md` | `worlds/hci-ux-dx/playbook-hci-core-v1.md` | `worlds/hci-ux-dx/kb-hci-usability-and-dialog-rules-v1.md`; классика UI/UX (Norman/Nielsen/Shneiderman/Krug) — `worlds/hci-ux-dx/kb-ui-ux-literature-evidence-v1.md`; карта чтения — `worlds/hci-ux-dx/map-hci-reading-v1.md`; hub — `worlds/hci-ux-dx/README.md` |
| Human perception (psychophysiology) | `worlds/cognition-human-perception/status-human-perception-v1.md` | `worlds/cognition-human-perception/playbook-human-perception-operational-v1.md` | `worlds/cognition-human-perception/kb-human-perception-fundamentals-v1.md`; **научные якоря (DOI):** `worlds/cognition-human-perception/kb-human-perception-scientific-evidence-v1.md`; **evidence по первоисточникам:** `worlds/cognition-human-perception/kb-human-perception-miller-1956-evidence-v1.md`, `worlds/cognition-human-perception/kb-human-perception-treisman-gelade-1980-evidence-v1.md`; **world (KE)** **cognition.human-perception** — `worlds/cognition-human-perception/README.md`; с HCI и продуктовыми ADR — см. operational playbook |
| Developer Experience (DE/DX) | `worlds/hci-ux-dx/status-de-dx-v1.md` | `worlds/hci-ux-dx/de-dx-playbook.md` | `tooling-debug-playbook.md`, `worlds/collaboration-git-pr/playbook-git-workflow-v1.md`, `worlds/collaboration-git-pr/playbook-pr-review-v1.md`; UI/продукт — `worlds/hci-ux-dx/ui-ux-playbook.md`, `worlds/hci-ux-dx/playbook-hci-core-v1.md`; литература IDE/DX (Osmani/Smalltalk/Boxer) — `worlds/hci-ux-dx/kb-ide-dx-literature-evidence-v1.md`; desktop IDE — домен **Avalonia UI (CascadeIDE)** |
| IT | `worlds/systems-it/status-it-v1.md` | `worlds/systems-it/playbook-it-core-systems-v1.md` | `worlds/systems-it/playbook-it-cloud-platform-economics-diagnostics-v1.md`, `worlds/systems-it/kb-it-cloud-platform-economics-diagnostics-rules-v1.md`; инженерная эвиденция .NET/C# — `worlds/software-engineering-evidence/kb-engineering-evidence-v1.md`, карта чтения — `worlds/software-engineering-evidence/map-engineering-reading-v1.md`; hub engineering — `worlds/software-engineering-evidence/README.md`; hub IT — `worlds/systems-it/README.md` |
| Automation (shell, scripting, containers) | — | `worlds/software-automation-scripting/automation-scripting-playbook.md` | `worlds/software-automation-scripting/powershell-playbook.md`, `worlds/software-automation-scripting/bash-playbook.md`, `worlds/software-automation-scripting/cmd-playbook.md`, `worlds/software-automation-scripting/python-playbook.md`, `worlds/software-automation-scripting/docker-playbook.md`; при парсинге/матчинге как ядре задачи — `worlds/pattern-regex/regex-playbook.md`; hub — `worlds/software-automation-scripting/README.md` |
| Host OS environments | — | `worlds/ops-host-environments/linux-environments-playbook.md` | `worlds/ops-host-environments/windows-environments-playbook.md`; hub — `worlds/ops-host-environments/README.md` |
| Ops network & admin tools | — | `worlds/ops-network-admin/playbook-ssh-operations-v1.md` | `worlds/ops-network-admin/playbook-nginx-admin-v1.md`, `worlds/ops-network-admin/playbook-wireshark-network-v1.md`, `worlds/ops-network-admin/playbook-1c-admin-v1.md`; hub — `worlds/ops-network-admin/README.md` |
| Ops reliability (data + incidents) | — | `worlds/ops-reliability/playbook-backup-db-v1.md` | `worlds/ops-reliability/playbook-incidents-tickets-v1.md`; hub — `worlds/ops-reliability/README.md` |
| Observability & network KB | — | `worlds/ops-observability-network/playbook-grafana-v1.md` | `worlds/ops-observability-network/kb-grafana-reference-v1.md`, `worlds/ops-observability-network/playbook-zabbix-monitoring-v1.md`, `worlds/ops-observability-network/kb-zabbix-reference-v1.md`, `worlds/ops-observability-network/playbook-network-fundamentals-v1.md`, `worlds/ops-observability-network/kb-network-reference-v1.md`; hub — `worlds/ops-observability-network/README.md` |
| Knowledge Engineering | `worlds/knowledge-engineering/status-knowledge-engineering-v1.md` | `worlds/knowledge-engineering/playbook-knowledge-engineering-core-v1.md` | `worlds/knowledge-engineering/kb-knowledge-engineering-multiworld-rules-v1.md`, `worlds/knowledge-engineering/kb-knowledge-engineering-mixed-worlds-rules-v1.md`, `worlds/knowledge-engineering/kb-knowledge-engineering-culture-routing-rules-v1.md`, `worlds/knowledge-engineering/kb-knowledge-engineering-country-conflicts-rules-v1.md`, `worlds/knowledge-engineering/kb-knowledge-engineering-operations-rules-v1.md`, `worlds/knowledge-engineering/matrix-culture-routing-v1.md`, `worlds/knowledge-engineering/matrix-do-not-transfer-v1.md`, `worlds/knowledge-engineering/world-modeling-playbook.md`, `worlds/knowledge-engineering/runbook-revisions-backup-v1.md`, `worlds/knowledge-engineering/runbook-kb-mcp-access-v1.md`; личный снимок корпуса ↔ роутер — `personal/bookshelf-corpus-vs-router-gaps-v1.md` (personal); hub — `worlds/knowledge-engineering/README.md` |
| Psychology | `worlds/psychology-models/status-psychology-v1.md` | `worlds/psychology-models/playbook-psychology-core-models-v1.md` | сквозные матрицы — `worlds/knowledge-engineering/matrix-culture-routing-v1.md`, `worlds/knowledge-engineering/matrix-do-not-transfer-v1.md`; kb — `worlds/psychology-models/kb-psychology-classical-schools-rules-v1.md`, `worlds/psychology-models/kb-psychology-empirical-evidence-rules-v1.md`, `worlds/psychology-models/kb-psychology-cultural-adaptation-rules-v1.md`, `worlds/psychology-models/kb-psychology-manipulation-and-influence-foundations-v1.md`; чтение — `worlds/psychology-models/map-psychology-reading-v1.md`; L1 Gender Studies — `worlds/psychology-models/psychology-gender-studies-subdomain-v1.md`; hub — `worlds/psychology-models/README.md` |
| Agent orchestration | — | `worlds/agent-orchestration/playbook-agent-autonomy-and-routing-v1.md` | `domains/agent-operations/` (сквозные протоколы: switch, integrity, multi-agent write), `worlds/agent-orchestration/playbook-captain-parallel-agents-v1.md`, `worlds/agent-orchestration/playbook-session-summary-and-chat-export-v1.md`, `worlds/agent-orchestration/playbook-learn-basics-when-stuck-v1.md`, `worlds/agent-orchestration/playbook-clarification-general-query-v1.md`, `worlds/agent-orchestration/kb-agent-foundation-two-layers-orientation-v1.md` (physical WFM vs semantic KB — ориентация); hub — `worlds/agent-orchestration/README.md` |
| Workspace & scope | — | `worlds/workspace-context/playbook-multi-project-context-v1.md` | `domains/agent-operations/playbook-project-switch-v1.md`, `domains/agent-operations/playbook-mode-switch-v1.md`, `kb-protocols-and-entities-one-pager-v1.md` (маркеры, Scope/Primary), `worlds/workspace-context/runbook-context-rehydrate-v1.md`, `worlds/workspace-context/active-scope-resolution-extended-v1.md`, `worlds/workspace-context/response-finalizer-extended-v1.md`; hub — `worlds/workspace-context/README.md` |
| Information management | — | `worlds/information-management/im-playbook.md` | `worlds/information-management/kb-public-identity-and-trust-core-v1.md`, `worlds/information-management/kb-im-open-questions-v1.md`, `worlds/information-management/tool-purpose-and-books-v1.md`; hub — `worlds/information-management/README.md` |
| Evidence & culture shelf | — | (см. kb в каталоге) | `worlds/evidence-humanities-shelf/kb-polyamory-reference-v1.md`, `worlds/evidence-humanities-shelf/kb-social-engineering-recognition-v1.md`, `worlds/evidence-humanities-shelf/kb-uncanny-valley-inverse-v1.md`, Covey/logic/utility/Russian/SA/history kb — в том же каталоге; hub — `worlds/evidence-humanities-shelf/README.md` |
| Software integration (APIs) | — | (внутри kb) | `worlds/software-integration-kb/kb-webapitoolkit-v1.md`, `worlds/software-integration-kb/kb-telegram-api-wtelegram-ids-v1.md`; hub — `worlds/software-integration-kb/README.md` |
| Culture (dialogue insights) | — | (внутри kb) | `worlds/culture-dialogue-insights/human-insights-from-dialogue-v1.md`; hub — `worlds/culture-dialogue-insights/README.md` |
| Software authoring & language | — | `worlds/software-authoring/code-writing-principles-v1.md` | `worlds/software-authoring/index-knowledge-language-v1.md`; hub — `worlds/software-authoring/README.md` |
| Aviation Human Factors | `worlds/aviation-human-factors/status-aviation-human-factors-v1.md` | `worlds/aviation-human-factors/playbook-aviation-human-factors-v1.md` | `worlds/aviation-human-factors/matrix-aviation-to-human-interaction-transfer-v1.md`, `worlds/aviation-human-factors/kb-aviation-human-factors-rules-v1.md`; термины PFD/MFD/EFIS/EICAS и метафора IDE (Cascade ADR 0021) — `worlds/aviation-human-factors/kb-aviation-pfd-mfd-efis-eicas-fundamentals-v1.md`; корень мира — `worlds/aviation-human-factors/playbook-aviation-v1.md` |
| Engineering (Evidence) | `worlds/software-engineering-evidence/status-engineering-reading-v1.md` | `worlds/software-engineering-evidence/kb-engineering-evidence-v1.md` | `worlds/software-engineering-evidence/map-engineering-reading-v1.md`, `worlds/software-engineering-evidence/kb-mcconnell-code-complete-2-chapter-map-v1.md` (McConnell *Code Complete* 2nd ed., карта глав + локальный source); hub — `worlds/software-engineering-evidence/README.md` |
| Medicine (Evidence) | `worlds/medicine-evidence/status-medicine-evidence-v1.md` | `worlds/medicine-evidence/playbook-medicine-evidence-v1.md` | `worlds/medicine-evidence/kb-bci-evidence-based-medicine-v1.md`; границы терапии/поддержки агента — `worlds/medicine-evidence/kb-therapy-and-support-boundaries-v1.md`; hub — `worlds/medicine-evidence/README.md` |
| Video (Videography + Surveillance) | — | (внутри kb) | `worlds/media-videography/kb-videography-cinematography-theory-v1.md` (теория + broadcast + кодеки; мир media.video-surveillance для CCTV); hub — `worlds/media-videography/README.md` |
| ML (Applied) | — | (внутри kb) | `worlds/software-ml-applied/kb-ml-applied-theory-v1.md` (парадигмы ML, OCR, barcode/QR; мир software.ml-applied); hub — `worlds/software-ml-applied/README.md` |
| Math / numerics (PDE, ODE, schemes, solver validation) | — | `worlds/math-numerics-pde/playbook-equation-ca-cuda-validation-v1.md` | `worlds/math-numerics-pde/kb-math-pde-fundamentals-v1.md`, `worlds/math-numerics-pde/kb-math-ode-ide-fundamentals-v1.md`, `worlds/math-numerics-pde/kb-math-numerical-schemes-fundamentals-v1.md`; валидация PDE / equation-to-ca-cuda — `worlds/math-numerics-pde/kb-pde-solver-validation-fundamentals-v1.md`, `worlds/math-numerics-pde/kb-equation-ca-cuda-validation-evidence-v1.md`; supplement — `router-math-numerics`, `router-equation-ca-cuda-validation`. Мир **math.numerics-pde**; hub — `worlds/math-numerics-pde/README.md` |
| Music | — | `worlds/arts-music/playbook-music-v1.md` | `worlds/arts-music/kb-music-theory-fundamentals-v1.md`, `worlds/arts-music/kb-music-acoustics-v1.md`, `worlds/arts-music/kb-music-temperaments-math-v1.md`, `worlds/arts-music/kb-music-non-western-v1.md` (мир arts.music); hub — `worlds/arts-music/README.md` |
| PHP / Laravel | `worlds/software-php-laravel/status-php-laravel-v1.md` | `worlds/software-php-laravel/playbook-php-v1.md` → `worlds/software-php-laravel/playbook-laravel-v1.md` | **Полный список kb — только в `worlds/software-php-laravel/status-php-laravel-v1.md` § Closure snapshot (+ README).** Карты кластеров: `worlds/software-php-laravel/index-knowledge-php-cluster-v1.md`, `worlds/software-php-laravel/index-knowledge-laravel-cluster-v1.md`, `worlds/software-php-laravel/index-knowledge-php-adjacent-ecosystem-v1.md`. Миры: `software.php`, `software.laravel`, `software.wordpress`, `software.drupal`, `software.symfony`, `software.web-backend`; hub — `worlds/software-php-laravel/README.md` |
| JavaScript (ECMAScript) | `worlds/software-javascript/status-javascript-v1.md` | `worlds/software-javascript/playbook-javascript-operational-v1.md` | Карта `worlds/software-javascript/index-knowledge-javascript-cluster-v1.md` (**fundamentals → operational**); snapshot — `worlds/software-javascript/status-javascript-v1.md`. Мир **`software.javascript`**. TypeScript — отдельно. RegExp — `worlds/pattern-regex/kb-regex-flavors-practice-v1.md` § JavaScript; hub — `worlds/software-javascript/README.md` |
| Regex | — | `worlds/pattern-regex/regex-playbook.md` | `worlds/pattern-regex/index-knowledge-regex-cluster-v1.md`, `worlds/pattern-regex/kb-regex-quickref-v1.md`, `worlds/pattern-regex/kb-regex-syntax-features-v1.md`, `worlds/pattern-regex/kb-regex-unicode-boundaries-v1.md`, `worlds/pattern-regex/kb-regex-engines-efficiency-v1.md`, `worlds/pattern-regex/kb-regex-flavors-practice-v1.md`, `worlds/pattern-regex/kb-regex-mre3-ru-chapter-map-v1.md` (кластер MRE3 / Friedl); hub — `worlds/pattern-regex/README.md` |
| Warehouse (barcode video, marketplaces) | `worlds/logistics-warehouse/status-warehouse-v1.md` | `worlds/logistics-warehouse/playbook-warehouse-v1.md` | `worlds/logistics-warehouse/kb-warehouse-marketplace-labels-v1.md`, `worlds/logistics-warehouse/kb-warehouse-barcode-video-v1.md` (по запросу — тот или оба). Мир logistics.warehouse |
| Avalonia UI (CascadeIDE) | `worlds/software-dotnet-avalonia/status-avalonia-cascade-ide-ui-v1.md` | `worlds/software-dotnet-avalonia/playbook-avalonia-dock-ui-v1.md` | `worlds/software-dotnet-avalonia/kb-avalonia-ui-dock-fundamentals-v1.md`; UX — `worlds/hci-ux-dx/playbook-hci-core-v1.md`, `worlds/hci-ux-dx/ui-ux-playbook.md`, `worlds/hci-ux-dx/kb-ui-ux-literature-evidence-v1.md`; принципы DX — `worlds/hci-ux-dx/kb-ide-dx-literature-evidence-v1.md`; кросс-стек .NET UI — `worlds/software-dotnet-csharp/frontend-dotnet-playbook.md`. **.NET / Roslyn** (software-dotnet-csharp/, software-dotnet-tooling-roslyn/): `worlds/software-dotnet-csharp/kb-dotnet-fundamentals-v1.md`, `worlds/software-dotnet-csharp/kb-dotnet-playbooks-v1.md`, `worlds/software-dotnet-tooling-roslyn/playbook-csharp-roslyn-mcp-diagnostics-v1.md`, `worlds/software-dotnet-tooling-roslyn/dotnet-roslyn-debug-playbook.md`. Мир **software.desktop-ui**; hub — `worlds/software-dotnet-desktop/README.md` |
<!-- /section:domain-entry-map-table -->

### Context Budget Modes

- **Tiny budget:** one `status-*` + one `playbook-*` only.
- **Normal budget:** add one `matrix-*` if cross-world transfer appears.
- **Deep budget:** include one targeted `kb-*` file by explicit question.

### Detailed domain routes (supplement)

Триггеры «когда грузить какой playbook/kb» по темам (секции `router-logic`, … `router-captain-parallel-agents`, `learn-basics-when-stuck-router`) — в **`knowledge/index-knowledge-router-supplement-v1.md`**. Те же `section_id`, что до рефакторинга; правки через MCP `upsert_knowledge_section` с **`file_path: index-knowledge-router-supplement-v1.md`**.

При узком контексте сначала **таблица доменов** выше и `status-*` / `playbook-*`; supplement — когда нужен **точечный** маршрут по запросу или по `route_context`.

## Б. Операционный базис (L0 и агент, не заменяют выбор домена)

Полный текст — **`knowledge/router-operational-baseline-v1.md`** (Baseline в agent-notes + extended, принципы агента и код, автономия, русский, SHOWCASE и MCP runbook). Здесь только **напоминание** при узком контексте:

- **L0 / baseline** — секции в `agent-notes.md` и `knowledge/*-extended-v1.md`, evidence по ядру при крахе барьеров; не отменяют строку таблицы доменов.
- **Агент** — `agent-memory-and-operating-principles-v1.md`, `worlds/software-authoring/code-writing-principles-v1.md`, `worlds/agent-orchestration/playbook-agent-autonomy-and-routing-v1.md`, `worlds/evidence-humanities-shelf/kb-russian-language-rules-v1.md`; при онбординге или споре о поведении читать шард целиком.
- **Демо / MCP** — `SHOWCASE.md`, `worlds/knowledge-engineering/runbook-kb-mcp-access-v1.md`.

## В. Безопасность и сопровождение индекса

### Safety Checks

Полный текст — **`knowledge/index-knowledge-router-safety-v1.md`**. Кратко: при **сжатии контекста** сначала снова **`index-knowledge-router-v1.md`**, затем по блоку **А**; неясный scope — не распухать по доменам без уточнения; давление / манипуляции / Integrity POST / TPM draft / приватность Cursor — в шарде.

### Maintenance Rule

Полный текст (структура **А/Б/В**, список `router-*` `section_id`, сплит supplement, Domain Entry Map, kb-public) — **`knowledge/index-knowledge-router-maintenance-v1.md`**.

### How to add a domain

Пошагово — раздел **How to add a domain** в **`knowledge/index-knowledge-router-maintenance-v1.md`**.

### Personal Layer (excluded from public)

- `knowledge/personal/**` — личный контур; не входит в публичную сборку. Маршрутизация: личные/уязвимые факты → `knowledge/personal/`. Правила: `PUBLISHING.md`.
- **Авто-создание:** при записи контента, который по критериям PUBLISHING считается личным (идентифицирует человека, личный диалог, имена, эмоциональный/внутренний контекст, внутренние планы), писать в `knowledge/personal/`. Если каталога нет — создать его, при необходимости добавить `knowledge/personal/README.md` с одной строкой: «Личный контур. Не публиковать. См. PUBLISHING.md»; затем записать контент туда.
