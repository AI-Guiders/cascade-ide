kb-base-cide-smoke
