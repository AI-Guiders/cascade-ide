Якорный файл состава KB-Base для CascadeIDE (проверка include и сборки).
